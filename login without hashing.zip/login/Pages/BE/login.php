<?php
session_start();
require_once "Database.php";

function hashPassword($password) {
    // The cost parameter can be increased to make the hash more secure, but it will also take longer to compute
    return password_hash($password, PASSWORD_DEFAULT, ['cost' => 10]);
}
if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['admin'])) {
    $username = $_POST["username"];
    $password = hashPassword($_POST["password"]); // hash the password using the hashPassword() function
    $isAdmin = $_POST['admin'] ? 1 : 0;
    echo "Username: $username<br>";
    echo "Password: $password<br>";
    echo "isAdmin: $isAdmin<br>";
    $stmt = $db->prepare("SELECT Pass, IsAdmin FROM users WHERE USERNAME = ?");
    $stmt->execute([$username]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row && password_verify($_POST["password"], $row['Pass']) && $row['IsAdmin'] == 1) { // compare the entered password with the hashed password from the database using password_verify()
        $_SESSION['username'] = $username;
        // Redirect to appropriate page based on isAdmin flag
        if($isAdmin == 1){
            //header('Location: welcomeadmin.html');
            echo "Success, welcome admin";
        } else {
            //header('Location: welcomeuser.html');
            echo "Success, welcome user";
        }
    } else {
        $error = "Invalid username or password";
        echo $error;
    }
}
else {
    echo "Please enter a username, password, and select admin or not.";
}
?>