<?php
session_start();
require_once "Database.php";

if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['admin'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $isAdmin = $_POST['admin'] ? 1 : 0;
    
    // Attempt to login with provided username and password
    $stmt = $db->prepare("SELECT IsAdmin FROM users WHERE USERNAME = ? AND Pass = ?");
    $stmt->execute([$username, $password]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if($row && $row['IsAdmin'] == 1) {
        $_SESSION['username'] = $username;
        // Redirect to appropriate page based on isAdmin flag
        if($isAdmin == 1){
            //header('Location: welcomeadmin.html');
            echo "Success, welcome admin";
        } else {
            //header('Location: welcomeuser.html');
            echo "Success, welcome user";
        }
    } else {
        $error = "Invalid username or password";
       // echo $error;
    }
}
else {
    echo "Please enter a username, password, and select admin or not.";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
</head>
<body>
    <div class="left">
        <div class="content">
            <div class="title">
                <span>Login</span>
            </div>             
            <div class="paragraph" style="border:0;">
                <form action="login.php" method="POST" name="signup-form" id="signup-form">
                    <?php if(isset($error)) { ?>
                        <p style="color:red;"><?php echo $error; ?></p>
                    <?php } ?>
                    <input type="text" name="username" placeholder="User Name" id="username" class="textfield">
                    <br><br>
                    <input type="password" name="password" placeholder="Password" id="pass" class="textfield">
                    <br><br>
                    <input type="checkbox" name="admin" id="admin" value="1">
                    <label for="admin">Are you an admin?</label>
                    <br><br>
                    <input type="submit" value="Login " class="mButton">
                    <br><br>
                    <input type="button" value="Cancel" class="mButton" onclick="ClearForm()">
                </form>
            </div>
            <br>
            <p style="margin-top: 10px; color:  black;">Not an admin? <a href="" style="color: black;">click here</a></p> 
        </div>
    </div>
<script>
function ClearForm() {
    document.getElementById("username").value = "";
    document.getElementById("pass").value = "";
}
</script>
</body>
</html>
